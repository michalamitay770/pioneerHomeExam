public class ThirdQ {


    // 1. Reutrn the highest score of each player
   /*

    SELECT PlayerId, MAX(Score)
    FROM Game_tbl
    GROUP BY id

    */


    // 2. Return players that did not play any game
   /*

      SELECT PlayerId
      FROM   Player_tbl
      WHERE  PlayerId NOT IN (SELECT PlayerId FROM Game_tbl)

    */

    // 3. Return players that their total score is more than 100
   /*

   SELECT PlayerId, SUM(Score) AS total_score
   FROM Player_tbl
   GROUP BY PlayerId
   HAVING SUM(Score)>100;

 */



}
