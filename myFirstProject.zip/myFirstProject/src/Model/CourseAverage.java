package Model;

public class CourseAverage {
    public int courseId;
    public double average;

    public CourseAverage(int courseId, int average) {
        this.courseId = courseId;
        this.average = average;
    }

    @Override
    public String toString() {
        return "CourseAverage{" + "courseId=" + courseId + ", average=" + average + '}';
    }
}
