package Model;

public class StudentCourseGrade {
    public int StudentId;
    public int CourseId;
    public int Grade;

    public int getStudentId() {
        return StudentId;
    }

    public void setStudentId(int studentId) {
        StudentId = studentId;
    }

    public int getCourseId() {
        return CourseId;
    }

    public void setCourseId(int courseId) {
        CourseId = courseId;
    }

    public int getGrade() {
        return Grade;
    }

    public void setGrade(int grade) {
        Grade = grade;
    }

    public StudentCourseGrade(int studentId, int courseId, int grade) {
        StudentId = studentId;
        CourseId = courseId;
        Grade = grade;
    }
}
