package Model;

import java.util.List;

public class StudentCourse {
    public int StudentId;
    public List<Integer> Courses;

}
