public class FirstQ {
    public static void main(String[] args) {
        System.out.println("Hello, World!");
        Integer[] ratesPrices=new Integer[]{5,4,9,1,8,7,7,9,6,8};
        System.out.println(maxRevenue(ratesPrices));
    }


    private static int maxRevenue(Integer[] ratesPrices) {
        if (ratesPrices == null || ratesPrices.length == 0) return 0;
        int min = ratesPrices[0];
        int max = ratesPrices[0];
        for (int i = 1; i < ratesPrices.length; i++) {
            int currentRate = ratesPrices[i];
            ;
            min = currentRate < min ? currentRate : min;
            max = currentRate > max ? currentRate : max;
        }
        return max - min;
    }

}
