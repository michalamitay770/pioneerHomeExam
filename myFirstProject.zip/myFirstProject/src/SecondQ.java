import Model.CourseAverage;
import Model.StudentCourseGrade;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

public class SecondQ {


    public static void main(String[] args) {
        List<StudentCourseGrade> items = new ArrayList<>();
        items.add(new StudentCourseGrade(1, 1123, 34));
        items.add(new StudentCourseGrade(1, 1124, 88));
        items.add(new StudentCourseGrade(2, 1123, 65));

        System.out.println("Student 1 courses: " + getStudentCourses(1, items));
        System.out.println("Student 2 courses: " + getStudentCourses(2, items));

        System.out.println("Courses average: " + getCoursesAverageGradeList(items));
    }

    //Build a list of all courses that student has (StudentCourse)
    private static List<Integer> getStudentCourses(int studentId, List<StudentCourseGrade> studentCourseGradeList) {
        List<Integer> courses = new ArrayList<>();
        for (StudentCourseGrade studentCourseGrade : studentCourseGradeList) {
            if (studentCourseGrade.StudentId == studentId) courses.add(studentCourseGrade.CourseId);
        }
        return courses;
    }

    //Build list of average course grade per course
    private static List<CourseAverage> getCoursesAverageGradeList(List<StudentCourseGrade> studentCourseGradeList) {
        List<CourseAverage> coursesAverage = new ArrayList<>();
        int courseSumGrades = 0;
        int courseGradesCount = 0;
        //not: as I i=understand, it's not allowed to use HashMap in this exam
        //so, I need to iterate on the list and it will cost O(n^2)
        //if I was able to use map , it will cost O(n)
        for (StudentCourseGrade studentCourseGrade : studentCourseGradeList) {
            if (coursesAverage.stream().filter(value -> value.courseId == studentCourseGrade.CourseId).findFirst().isPresent())
                continue;
            List<Integer> grades = studentCourseGradeList.stream().filter(value -> value.CourseId == studentCourseGrade.CourseId).map(StudentCourseGrade::getGrade).collect(Collectors.toList());
            coursesAverage.add(new CourseAverage(studentCourseGrade.CourseId, (grades.stream().mapToInt(i -> i.intValue()).sum() ) / grades.size()));
        }
        return coursesAverage;
    }
}


